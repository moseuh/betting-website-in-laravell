<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamsStats extends Model
{
    protected $table = 'statistics';

    public $timestamps= false;
}
